import { LightningElement } from 'lwc';

export default class Accordian extends LightningElement {
    activeSectionMessage = '';
    handleSectionToggle(event){
        const openSections = event.detail.openSections;
        console.log(openSections.toString());
        // if(openSections.length === 0)
        // this.activeSectionMessage = 'All sections are closed';
        // else
        // this.activeSectionMessage = openSections.JOIN(',');
    }

}