import { LightningElement, track,api } from 'lwc';

export default class LearningCardHeader extends LightningElement {
    isHome = false;
    goToHomeBtn(){
        this.isHome = true;
        this.dispatchEvent(new CustomEvent('gotohomepage'));
    }
    goToLearn(){
        this.dispatchEvent(new CustomEvent('gotolearn'));
    }
    goToFeedback(){
        this.dispatchEvent(new CustomEvent('gotofeedback'));
    }
}
