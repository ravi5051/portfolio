import { LightningElement, wire } from 'lwc';
import accountContactAndOpportunitiesRecord from '@salesforce/apex/AccountContactOpportunityControler.getAccountContactAndOpportunity';

export default class AccordianAccountContactOpportunity extends LightningElement {
    wrapperData;
    error;
    @wire(accountContactAndOpportunitiesRecord) records({data, error}){
        if(data){
            this.wrapperData = data;
            this.error = undefined; 
            console.log(this.wrapperData);
        }else if(error){
            this.error = error;
            console.log(this.error);
            this.wrapperData = undefined;
        }
    }
}