import { LightningElement } from 'lwc';

export default class Buttton extends LightningElement {
    isSelected = false;
    onClickHandler(){
        this.isSelected = !this.isSelected;

    }
}