import { LightningElement, wire, track} from 'lwc';
import { loadStyle } from 'lightning/platformResourceLoader';
import My_Custom_Css_File from '@salesforce/resourceUrl/MyCustomCssFile';
import searchedContacts from '@salesforce/apex/ContactSearchControler.searchedContacts'
import allAccounts from '@salesforce/apex/AllAccountsControler.allAccounts'

const columns =[
    {
        label : 'Id',
        fieldName : 'Id',
        type : 'string'
    },
    {
        label : 'Name',
        fieldName : 'Name',
        type : 'string'
    },
    {
        label : 'Rating',
        fieldName : 'Rating',
        type : 'string'
    },
]
export default class PractiseComponent extends LightningElement {
    //to overwrite the css using static resource

    renderedCallback() {
        Promise.all([loadStyle(this, My_Custom_Css_File)]);
    }
    handleOpenInNewTab(e){
        if(e.target.header == 'Elephant')
        window.open(
            'https://images.unsplash.com/photo-1592670130429-fa412d400f50?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1862&q=80',
            '_blank'
            );
        else if(e.target.header == 'Monkey')
            window.open(
                'https://imageio.forbes.com/specials-images/imageserve/5faad4255239c9448d6c7bcd/Best-Animal-Photos-Contest--Close-Up-Of-baby-monkey/960x0.jpg?format=jpg&width=960',
                '_blank'  
            )
        else if(e.target.header == 'Lion')
            window.open(
                'https://images.pexels.com/photos/247502/pexels-photo-247502.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
                '_blank'    
            )
    }

    searched;
    contacts;
    error;
    isVisible = false;
    //using @wire 
    searchContact(){
        this.isVisible = false;
        this.isVisible = true;
        const toSearch = this.template.querySelector('.toSearch');
        this.searched = toSearch.value;
    }
    @wire (searchedContacts, {searchPattern :'$searched'}) contactsList({data,error}){
        if(data){
            this.contacts = data;
            this.error = undefined;
        }else if(error){
            this.data = undefined;
            this.error = error;
        }
    }

    // imprative call apex start
    // searchContact(){
    //     // this.isVisible = false;
    //     this.isVisible = true;
    //     const toSearch = this.template.querySelector('.toSearch');
    //     this.searched = toSearch.value;
    //     searchedContacts({searchPattern : this.searched})
    //     .then(
    //         (data) => {
    //             this.contacts = data;
    //         }
    //     )
    //     .catch(
    //         (error) => {
    //             this.error = error;
    //         }
    //     );
    // }
    //imprative call end
    link = ''
    getContactUrl(e){
        this.link = 'https://algocirruspvtltd-1c-dev-ed.develop.lightning.force.com/lightning/r/Account/'+e.target.dataset.id+'/view';
    }

    //showing accounts in the form of table
    data;
    error;
    columns = columns;
    @wire (allAccounts) accounts({data,error}){
        if(data){
            this.data = data;
            this.error = undefined;
            console.log('data',data);
        }
        else if(error){
            this.error = error;
            this.data = undefined;;;
        }
    }
    connectedCallback(){
        console.log('Hi i am onnectedCallback');
    }
    constructor(){
        super();
        console.log('hi i am constructor');
    }

}