import { LightningElement } from 'lwc';
import icons from '@salesforce/resourceUrl/Icons';
import NAME_FIELD from '@salesforce/schema/Learning_Feedback__C.Name';
import FEEDBACK_RATING_FIELD from '@salesforce/schema/Learning_Feedback__C.Feedback_Rating__c';
import EMAIL from '@salesforce/schema/Learning_Feedback__C.Email__c';
import FEEDBACK_FIELD from '@salesforce/schema/Learning_Feedback__C.Feedback__c';
import createFeedbackRecord from '@salesforce/apex/CreateFeedbackRecordController.createRecord';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
export default class LearningFeedback extends LightningElement {
    rating1ClipImage = icons + '/icons/' + 'rating1-clip-image' + '.png';
    rating2ClipImage = icons + '/icons/' + 'rating2-clip-image' + '.png';
    rating3ClipImage = icons + '/icons/' + 'rating3-clip-image' + '.png';
    rating4ClipImage = icons + '/icons/' + 'rating4-clip-image' + '.png';
    rating5ClipImage = icons + '/icons/' + 'rating5-clip-image' + '.png';
    forestClipImage = icons + '/icons/' + 'forest-clip-image' + '.png';
    
    name = NAME_FIELD;
    feedbackRating = FEEDBACK_RATING_FIELD;
    feedback = FEEDBACK_FIELD;
    email = EMAIL;

    feedbackRecord = {
        Name : this.name,
        Feedback_Rating__c : this.feedbackRating,
        Feedback__c : this.feedback,
        Email__c : this.email
    }
    clearFields(){
        const allInputFields = this.template.querySelectorAll('.textInput');
        allInputFields.forEach(element=>{
            element.value = null;
        })
        this.template.querySelector('.rating-icon-big').classList.remove('rating-icon-big');
    }
    onClickCreateFeedbackRecord(){
        createFeedbackRecord({feedbackRec : this.feedbackRecord})
        .then(result=>{
            console.log(result);
            console.log('feedback submitted successfully');
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Success',
                    message: 'Account created',
                    variant: 'success',
                }),
            );
        })
        .catch(error=>{
            console.log(error);
            console.log('failed to submit the feedback');
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error creating record',
                    message: error.body.message,
                    variant: 'error',
                }),
            );
        })
        this.clearFields();
    }
    handleRatingChange(event){
        this.feedbackRecord.Feedback_Rating__c = event.currentTarget.dataset.id;
        this.template.querySelectorAll('.rating-icon-big').forEach(element=>{
            element.classList.remove('rating-icon-big');
        })
        event.target.classList.add('rating-icon-big');
    }
    handleNameChange(event){
        this.feedbackRecord.Name = event.target.value;
    }
    handleEmailChange(event){
        this.feedbackRecord.Email__c = event.target.value;
    }
    handleFeedbackChange(event){
        this.feedbackRecord.Feedback__c = event.target.value;
    }
}