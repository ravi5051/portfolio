import { LightningElement } from 'lwc';
// import LightningAlert from 'lightning/alert';
export default class Accordion extends LightningElement {
    activeSectionMessage = '';
    buttonName = ''
    mode = "light-mode";
    modeText =  "dark-mode";
    handleToggleSection(event) {
        this.activeSectionMessage ='Open section name:  ' + event.detail.openSections;
    }
    redButton = this.template.querySelector('.red');
    blueButton = this.template.querySelector('.blue');
    greenButton = this.template.querySelector('.green');

    handleClick(e){
        this.buttonName = e.target.label;
        console.log("colored buttton : "+e.target.label);
        // LightningAlert.open({
        //     message: 'this is the alert message',
        //     theme: 'warning', // a red theme intended for error states
        //     label: 'Error!', // this is the header text
        //     variant: 'headerless',
        // });
    }

    toggleMode(){
        if(this.mode == "light-mode" && this.modeText == "dark-mode"){
            this.modeText = "light-mode";
            this.mode = "dark-mode";
        }
        else{
            this.modeText = "dark-mode";
            this.mode = "light-mode";
        }
    }
}