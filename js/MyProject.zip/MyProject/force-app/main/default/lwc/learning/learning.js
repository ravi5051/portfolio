import { LightningElement, track, api } from 'lwc';
import icons from '@salesforce/resourceUrl/Icons';
import clipImage from '@salesforce/resourceUrl/Clip_Image';
export default class LearningTile extends LightningElement {
    data;
    error;
    newData = [];
    isFootervisible = true;
    @track editableData =[];
    openedCardData;
    isFooterVisible = true;
    isPage1Open = false;
    isPage2Open = false;
    @api isHome = false;
    supportiveContents;
    clickedCardName = '';
    clickedCardTopic;
    clickedCardImage;
    lionClipImageUrl = icons + '/icons/lion-clip-image.png';
    grassClipImageUrl = icons + '/icons/grass-clip-image.png';
    @api isLearningVisible = false;
    clipImageUrl = clipImage;
    isBreadCrumbVisible = false;
    isFeedbackVisible = false;
    clickedCardDescription;
    openClickedCard = false
    connectedCallback(){
        this.isHome=true;
    }
    addMoreText(event){
    }
    @api goToLearnPage(){
        console.log('fired goToLearnPage');
        this.isBreadCrumbVisible = true;
        this.makeAllFalse();
        this.isLearningVisible = true;
        this.template.querySelector('c-learning-card-content').goBackExplore();
        console.log('2356789');
    }
    homePageVisible(){
        this.makeAllFalse();
        this.isFootervisible = false;
    }
    goToFeedbackPage(){
        this.makeAllFalse();
        this.isFeedbackVisible = true;
    }
    makeAllFalse(){
        this.isHome = false;
        this.isLearningVisible = false;
        this.openClickedCard = false;
        this.isFootervisible = false;
        this.isFeedbackVisible = false;
        this.isFootervisible = true;
    }
    makeAllTrue(){
        this.isHome = true;
        this.isLearningVisible = true;
        this.openClickedCard = true;
        this.isFootervisible = true;
        this.isFeedbackVisible = true;
    }
}