import { LightningElement, wire, api } from 'lwc';
import clickedCardRecord from '@salesforce/apex/LearningTopicControler.getClickedCard';
// import learningRecord from '@salesforce/apex/LearningTopicControler.learningtopicControler';
// import IMAGES from '@salesforce/resourceUrl/Images_For_Cards';
import icons from '@salesforce/resourceUrl/Icons';
export default class LearningClickedCard extends LightningElement {
    @api recordId;
    isSupportiveContents = false;
    supportiveContents;
    clickedCardName = '';
    clickedCardTopic;
    clickedCardImage;
    clickedCardDescription;
    denClipImage = icons + '/icons/den-clip-image.png';
    @wire (clickedCardRecord, {recordId:'$recordId'} ) 
    records({data, error}){
        if(data){
            this.supportiveContents = data;
        }else if(error){
            console.log('error-->',error);
        }
        this.isLearningVisible = false;
        this.openClickedCard = true;
        this.isSupportiveContents = this.supportiveContents == null || this.supportiveContents == undefined ? false : true;
    }
    renderedCallback(){
        const contentCards = this.template.querySelectorAll('.content-card');
        for(let i = 1; i <= contentCards.length; i = i+2){
            contentCards[i].classList.add('slds-float_right');
        }
        this.isLearningVisible = false;
    }
    goToLearn(){
        this.dispatchEvent(new CustomEvent('gotolearn'));
    }
}