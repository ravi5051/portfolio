import { LightningElement, track } from 'lwc';
import learningRecords from '@salesforce/apex/LearningTileControler.learningTileControler';
import IMAGES from "@salesforce/resourceUrl/Images_For_Cards";
export default class LearningTile extends LightningElement {
    data;
    error;
    newData = [];
    @track editableData =[];

    connectedCallback(){
        this.getTileControlerData();
    }
    newObjData = {};
    getTileControlerData(){
        learningRecords()
        .then(result=>{
            this.editableData = [...result];
            for(let index = 0; index < this.editableData.length; index++){
                let json = {...this.editableData[index]};
                json.Image__c = IMAGES + '/Images/' + json.Image__c + '.jpg';
                if(json.Description__c.length > 65){
                    json['showMore'] = json.Description__c.substring(66, json.Description__c.length)
                    json.Description__c = json.Description__c.substring(0,66);
                }
                this.editableData[index] = json;
            }
            this.newData = this.editableData;
        })
        .catch(error=>{
            console.log(error);
        });
    }
    addMoreText(event){
        
    }
}