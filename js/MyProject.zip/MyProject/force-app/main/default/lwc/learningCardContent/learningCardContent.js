import { LightningElement, track, api } from 'lwc';
import learningRecords from '@salesforce/apex/LearningTopicControler.learningtopicControlers';
import icons from '@salesforce/resourceUrl/Icons';
import IMAGES from '@salesforce/resourceUrl/Images_For_Cards';


export default class LearningTile extends LightningElement {
    data;
    error;
    newData = [];
    @track editableData =[];
    learningLionClipImageUrl = icons + '/icons/learning-lion-clip-image.png';
    isLearningVisible = true;
    openClickedCard = false;
    recId;
    connectedCallback(){
        this.getTileControlerData();
    }
    getTileControlerData(){
        learningRecords()
        .then(result => {
            this.editableData = [...result];
            for(let index = 0; index < this.editableData.length; index++){
                let json = {...this.editableData[index]};
                json.Image__c = IMAGES + '/Images/' + json.Image__c.toLowerCase() + '.jpg';
                if(json.Description__c.length > 65){
                    json['showMore'] = json.Description__c.substring(66, json.Description__c.length)
                    json.Description__c = json.Description__c.substring(0,66);
                }
                this.editableData[index] = json;
            }
            this.newData = this.editableData;
        })
        .catch(error => {
            console.log(error);
        });
    }
    handleCardClick(event){
        this.isLearningVisible = false;
        this.openClickedCard = true;
        this.recId = event.currentTarget.dataset.id;
    }
    scrollOnClick(){
        const learningCards = this.template.querySelector('[data-section="learning-card"]');
        learningCards.scrollIntoView({behavior: "smooth", block: "start", inline: "nearest"});
    }
    @api goBackExplore(){
        this.isLearningVisible = true;
        this.openClickedCard = false;
    }
}