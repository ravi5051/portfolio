// import { LightningElement} from 'lwc';

// export default class StudentRecord extends LightningElement {
//     admissionNumber = null;
//     name = null;
//     fathersName = null;
//     mothersName = null;
//     courseName = null;
//     semester = null;
//     subject1Name = null;
//     subject1TotalMarks = null;
//     subject1PassingMarks = null;
//     subject1TheoryMarks = null;
//     subject1PracticalMarks = null;
//     subject1TotalObtMarks = null;
//     subject2Name = null;
//     subject2TotalMarks = null;
//     subject2PassingMarks = null;
//     subject2TheoryMarks = null;
//     subject2PracticalMarks = null;
//     subject2TotalObtMarks = null;
//     subject3Name = null;
//     subject3TotalMarks = null;
//     subject3PassingMarks = null;
//     subject3TheoryMarks = null;
//     subject3PracticalMarks = null;
//     subject3TotalObtMarks = null;
//     subject4Name = null;
//     subject4TotalMarks = null;
//     subject4PassingMarks = null;
//     subject4TheoryMarks = null;
//     subject4PracticalMarks = null;
//     subject4TotalObtMarks = null;
//     subject5Name = null;
//     subject5TotalMarks = null;
//     subject5PassingMarks = null;
//     subject5TheoryMarks = null;
//     subject5PracticalMarks = null;
//     subject5TotalObtMarks = null;
//     totalMarks = null;
//     percentage = null;
//     result = null;
//     isFormNotActive = false;
//     isFormActive = !this.isFormNotActive;
//     isLoaded = false;
//     carsList = ['ford','bugati','benz','lamborghini'];
//     handleOnClick(){
//         this.isLoaded = true;
//         setTimeout(()=>{
//             this.isLoaded = false;
//             this.isFormNotActive = true;
//             this.isFormActive = !this.isFormNotActive;
//             let inputs = this.template.querySelectorAll('lightning-input');
//             console.log(inputs);
//             const valuesMap = new Map();
//             inputs.forEach(function(element){
//                 valuesMap.set(element.name, element.value);
//             },this);
//             console.log(valuesMap);
//             personalDetails = {name:"",admissionNumber : "", fathersName : "", mothersName : "", courseName : "", semester : ""};
//             this.name = valuesMap.get('name');
//             this.admissionNumber = valuesMap.get('admissionNumber');
//             this.fathersName = valuesMap.get('fathersName');
//             this.mothersName = valuesMap.get('mothersName');
//             this.courseName = valuesMap.get('courseName');
//             this.semester = valuesMap.get('semester');
//             this.subject1Name = valuesMap.get('subject1Name');
//             this.subject1TotalMarks = valuesMap.get('subject1TotalMarks');
//             this.subject1PassingMarks = valuesMap.get('subject1PassingMarks');
//             this.subject1TheoryMarks = valuesMap.get('subject1TheoryMarks');
//             this.subject1PracticalMarks = valuesMap.get('subject1PracticalMarks');
//             this.subject1TotalObtMarks = parseInt(this.subject1TheoryMarks) + parseInt(this.subject1PracticalMarks);
//             this.subject2Name = valuesMap.get('subject2Name');
//             this.subject2TotalMarks = valuesMap.get('subject2TotalMarks');
//             this.subject2PassingMarks = valuesMap.get('subject2PassingMarks');
//             this.subject2TheoryMarks = valuesMap.get('subject2TheoryMarks');
//             this.subject2PracticalMarks = valuesMap.get('subject2PracticalMarks');
//             this.subject2TotalObtMarks = parseInt(this.subject2TheoryMarks) + parseInt(this.subject2PracticalMarks);
//             this.subject3Name = valuesMap.get('subject3Name');
//             this.subject3TotalMarks = valuesMap.get('subject3TotalMarks');
//             this.subject3PassingMarks = valuesMap.get('subject3PassingMarks');
//             this.subject3TheoryMarks = valuesMap.get('subject3TheoryMarks');
//             this.subject3PracticalMarks = valuesMap.get('subject3PracticalMarks');
//             this.subject3TotalObtMarks = parseInt(this.subject3TheoryMarks) + parseInt(this.subject3PracticalMarks);
//             this.subject4Name = valuesMap.get('subject4Name');
//             this.subject4TotalMarks = valuesMap.get('subject4TotalMarks');
//             this.subject4PassingMarks = valuesMap.get('subject4PassingMarks');
//             this.subject4TheoryMarks = valuesMap.get('subject4TheoryMarks');
//             this.subject4PracticalMarks = valuesMap.get('subject4PracticalMarks');
//             this.subject4TotalObtMarks = parseInt(this.subject4TheoryMarks) + parseInt(this.subject4PracticalMarks);
//             this.subject5Name = valuesMap.get('subject5Name');
//             this.subject5TotalMarks = valuesMap.get('subject5TotalMarks');
//             this.subject5PassingMarks = valuesMap.get('subject5PassingMarks');
//             this.subject5TheoryMarks = valuesMap.get('subject5TheoryMarks');
//             this.subject5PracticalMarks = valuesMap.get('subject5PracticalMarks');
//             this.subject5TotalObtMarks = parseInt(this.subject5TheoryMarks) + parseInt(this.subject5PracticalMarks);
//             this.totalMarks = parseInt(this.subject1TotalObtMarks) + parseInt(this.subject2TotalObtMarks) + parseInt(this.subject3TotalObtMarks) + parseInt(this.subject4TotalObtMarks) + parseInt(this.subject5TotalObtMarks);
//             // this.totalMarks = IsNaN(temp) ? null : temp;
//             this.percentage = (parseFloat(this.totalMarks) * 100/(parseInt(this.subject1TotalMarks) + parseInt(this.subject2TotalMarks) + parseInt(this.subject3TotalMarks) + parseInt(this.subject4TotalMarks) + parseInt(this.subject5TotalMarks))).toFixed(2);
//             if(!isNaN(this.percentage) && this.percentage >= 60)
//             this.result = '1st Division';
//             else if(!isNaN(this.percentage) && this.percentage >= 45 && this.percentage < 60)
//             this.result = '2nd Division';
//             else if(!isNaN(this.percentage) && this.percentage >= 30 && this.percentage < 45)
//             this.result = '3rd Division';
//             else if(!isNaN(this.percentage) && this.percentage < 30)
//             this.result = 'Fail';
//             else if(isNaN(this.percentage))
//             this.result = null;
//         }, 2000);
//     }
//     handleOnClickReset(){
//         this.isFormNotActive = false;
//         this.isFormActive = !this.isFormNotActive;
//         let inputs = this.template.querySelectorAll('lightning-input');
//         inputs.forEach(function(element){
//             element.value = null;
//         },this);
//     }
//     generateInputForAll(){

//     }
// }

import { LightningElement} from 'lwc';

export default class StudentRecord extends LightningElement {
    numOfInput = 0;
    isVisible = false;
    isResultVisible = false;
    allSubjectsData =  [];
    isButtonVisible = true;
    arrayOfInput = [];
    keysArray = [];
    valuesArray = [];
    admissionNumber = null;
    name = null;
    fathersName = null;
    mothersName = null;
    courseName = null;
    semester = null;
    totalMarks = null;
    percentage = null;
    result = null;
    isFormNotActive = false;
    isFormActive = !this.isFormNotActive;
    isLoaded = false;
    addRows(){
        const inputRow = this.template.querySelector('.rowToInsert');
        this.numOfInput = inputRow.value;
        this.isVisible = false;
        this.isVisible = true;
        for ( let index = 0; index < inputRow.value; index++) {
            this.arrayOfInput.push(index);  
        }
    }
    deleteRows(){
        this.arrayOfInput = [];
        this.isVisible = false;
        this.isVisible = true;
    } 
    fieldsNotNull(){
        const inputFields = this.template.querySelectorAll('lightning-input');
        let tmp = false;
        inputFields.forEach((element)=>{
            if(element.value.trim() === ""){
                tmp = true;
            }
            // console.log('element value-->', element.value, 'tmp --> ', tmp);
        });
        if(tmp){
            this.isButtonVisible = false;
            this.isButtonVisible = true;
        }
        else{
            this.isButtonVisible = true;
            this.isButtonVisible = false;
        }
    }
    
    handleOnClick(){
        this.spinnerCall();
        setTimeout(()=>{
            this.isFormNotActive = true;
            this.isFormActive = !this.isFormNotActive;
            let inputs = this.template.querySelectorAll('lightning-input');
            const valuesMap = new Map();
            inputs.forEach(function(element){
                valuesMap.set(element.name, element.value);
            });
            this.name = valuesMap.get('name');
            this.admissionNumber = valuesMap.get('admissionNumber');
            this.fathersName = valuesMap.get('fathersName');
            this.mothersName = valuesMap.get('mothersName');
            this.courseName = valuesMap.get('courseName');
            this.semester = valuesMap.get('semester');
            this.isResultVisible = true;
            console.log('before');
            let rowData = this.template.querySelectorAll('lightning-input[data-subject="subjects"]');
            console.log('after');
            if(rowData){
                let totalFields = parseInt(rowData.length/this.numOfInput);
                let counter = 1;
                let obj = {};
                rowData.forEach(currentItem => {
                    console.log('currentItem.name-->',currentItem.name);
                    obj[currentItem.name] = currentItem.value;
                    if(counter == totalFields){
                        obj['totalObtMarks'] = parseInt(obj['subjectPracticalMarks']) + parseInt(obj['subjectTheoryMarks']);
                        this.allSubjectsData.push(obj);
                        this.totalMarks += obj['totalObtMarks'];
                        obj = {};
                        counter = 0;
                    }
                    counter++;
                });
                this.keysArray=Object.keys(this.allSubjectsData[0]);
                this.valuesArray = this.allSubjectsData.map(Object.values);
                this.percentage = parseFloat(this.totalMarks) / this.numOfInput;
                if(!isNaN(this.percentage) && this.percentage >= 60)
                this.result = '1st Division';
                else if(!isNaN(this.percentage) && this.percentage >= 45 && this.percentage < 60)
                this.result = '2nd Division';
                else if(!isNaN(this.percentage) && this.percentage >= 30 && this.percentage < 45)
                this.result = '3rd Division';
                else if(!isNaN(this.percentage) && this.percentage < 30)
                this.result = 'Fail';
                else if(isNaN(this.percentage))
                this.result = null;
            }
        }, 1000);
    }
    handleOnClickReset(){
        this.isFormNotActive = false;
        this.isFormActive = !this.isFormNotActive;
        this.isLoaded = false;
        let inputs = this.template.querySelectorAll('lightning-input');
        inputs.forEach(function(element){
            element.value = null;
        });
        this.numOfInput = 0;
        this.arrayOfInput = [];
        this.isVisible = false;
        this.isResultVisible = false;
        this.allSubjectsData =  [];
        this.keysArray = [];
        this.valuesArray = [];
        this.isButtonVisible = true;
        this.personalDetailsList = [];
    }
    generateInputForAll(){
        
    }
    spinnerCall(){
        this.isLoaded = true;
        setTimeout(()=>{
            this.isLoaded = false;
        },2000);
    }
}