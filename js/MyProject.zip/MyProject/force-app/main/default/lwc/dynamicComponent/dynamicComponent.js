import { LightningElement } from 'lwc';

export default class DynamicComponent extends LightningElement {
    
    numOfInput = 0;
    arrayOfInput = [];
    isVisible = false;
    isResultVisible = false;
    allSubjectsData =  [];
    keysArray = [];
    valuesArray = [];
    objj={};
    
    addRowInput(){
        const inputRow = this.template.querySelector('.rowToInsert');
        this.numOfInput = inputRow.value;
        this.isVisible = true;
        for ( let index = 0; index < inputRow.value; index++) {
            this.arrayOfInput.push(index);  
        }
        console.log(this.objj);
    }
    deleteRows(){
        this.arrayOfInput = [];
        this.isVisible = false;
        this.isVisible = true;
    } 
    
    getResult(){
        this.isResultVisible = true;
        let rowData = this.template.querySelectorAll('lightning-input[data-subject="subjects"]');
        let totalFields = parseInt(rowData.length/this.numOfInput);
        console.log('this.numOfInput-->',this.numOfInput);
        console.log('totalFields-->',totalFields);
        
        let counter = 1;
        let obj = {};
        rowData.forEach(currentItem => {
            console.log('currentItem.name-->',currentItem.name);
            obj[currentItem.name] = currentItem.value;
            if(counter == totalFields){
                this.allSubjectsData.push(obj);
                obj = {};
                counter = 0;
            }
            counter++;
        });
        this.keysArray=Object.keys(this.allSubjectsData[0]);
        this.valuesArray = this.allSubjectsData.map(Object.values);
        console.log('valuesArray--->',JSON.stringify(this.valuesArray));
        // console.log('--KEYS--', JSON.stringify(this.keysArray));
        console.log(JSON.stringify(this.allSubjectsData));
        // console.log(this.allSubjectsData[0]);
        // console.log(this.allSubjectsData[1]);
    }
    
}