import { LightningElement, api } from 'lwc';

export default class Greet extends LightningElement {
    @api msg = "hello";
}