import { LightningElement } from 'lwc';
import icons from '@salesforce/resourceUrl/Icons';
export default class LearningCardFooter extends LightningElement {
    facebookIcon = icons + '/icons/' + 'facebook-icon' + '.png';
    instagramIcon = icons + '/icons/' + 'instagram-icon' + '.png';
    linkedInIcon = icons + '/icons/' + 'linkedin-icon' + '.png';
    gmailIcon = icons + '/icons/' + 'gmail-icon' + '.png';
    youtubeIcon = icons + '/icons/' + 'youtube-icon' + '.png';
    websiteIcon = icons + '/icons/' + 'website-icon' + '.png';
}